import getBase, { add, multiply } from './02-19-module.mjs';

console.log(add(4));
console.log(getBase());
